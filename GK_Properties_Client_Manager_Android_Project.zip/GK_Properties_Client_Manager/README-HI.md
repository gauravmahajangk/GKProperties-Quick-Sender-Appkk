# GK Properties Client Manager

यह Android project फोन की contacts list से clients import करता है, duplicate numbers हटाता है, local client notes रखता है और सहमति दर्ज किए गए client के लिए WhatsApp Business chat खोलता है।

## APK बनाने का आसान तरीका (सिर्फ Android मोबाइल से)

1. इस ZIP को डाउनलोड करके Extract करें।
2. GitHub पर नया repository बनाएँ: `GK-Properties-Client-Manager` (Private रख सकते हैं)।
3. नए repository में `Add file` → `Upload files` चुनें।
4. ZIP को पहले Extract करें; अंदर की सभी files/folders repository के root में upload करें (ZIP को सीधे upload न करें)।
5. `Commit changes` दबाएँ।
6. Repository में `Actions` tab खोलें।
7. `Build GK Properties Client Manager APK` workflow चुनें और `Run workflow` दबाएँ।
8. Build पूरा होने पर workflow run खोलें → नीचे `Artifacts` में `GK-Properties-Client-Manager-APK` डाउनलोड करें।
9. ZIP artifact खोलकर `app-debug.apk` इंस्टॉल करें। Android पूछे तो browser/files app के लिए “Install unknown apps” की अनुमति दें।

## पहली बार इस्तेमाल

- Import phone contacts दबाएँ और Contacts permission दें।
- नंबर डुप्लिकेट होने पर दोबारा नहीं जुड़ेंगे।
- ग्राहक की अनुमति मिलने पर ही consent checkbox चुनें।
- Open WhatsApp Business दबाने पर chat और भरा हुआ message खुलेगा; Send आप WhatsApp में खुद दबाएँ।

## सीमाएँ

- यह ऐप WhatsApp की private chat/contact database नहीं पढ़ता। केवल Android phone book import होती है।
- यह WhatsApp messages अपने आप नहीं भेजता, bulk blasting या timer sending नहीं करता।
- नंबर फोन में international format में सेव होते हैं; 10-digit Indian number के आगे 91 जोड़ा जाता है।
- Client data इसी फोन में local रूप से रहता है; ऐप uninstall/data clear करने पर हट सकता है।
- यह शुरुआती MVP है; अभी cloud sync, CSV export/import, custom templates, multi-user login और official WhatsApp Business Platform API शामिल नहीं हैं।
