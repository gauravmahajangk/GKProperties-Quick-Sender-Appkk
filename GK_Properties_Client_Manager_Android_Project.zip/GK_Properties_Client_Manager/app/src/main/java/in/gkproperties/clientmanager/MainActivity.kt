package in.gkproperties.clientmanager

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

data class Client(
    val name: String,
    val phone: String,
    var optedIn: Boolean = false,
    var note: String = ""
)

class MainActivity : Activity() {
    private val clients = mutableListOf<Client>()
    private lateinit var listBox: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var countText: TextView
    private val prefs by lazy { getSharedPreferences("gk_clients", MODE_PRIVATE) }
    private val requestContacts = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadClients()
        buildScreen()
        renderClients()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF6F7FB.toInt())
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(TextView(this).apply {
            text = "GK PROPERTIES"
            textSize = 25f
            setTextColor(0xFF183153.toInt())
            typeface = Typeface.DEFAULT_BOLD
        })
        page.addView(TextView(this).apply {
            text = "CLIENT MANAGER"
            textSize = 14f
            setTextColor(0xFF52627A.toInt())
        })
        countText = TextView(this).apply { textSize = 14f; setPadding(0, 12, 0, 12) }
        page.addView(countText)

        val importBtn = button("Import phone contacts") {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                importContacts()
            } else requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), requestContacts)
        }
        page.addView(importBtn)

        val addName = EditText(this).apply { hint = "Client name"; singleLine = true }
        val addPhone = EditText(this).apply {
            hint = "Mobile number with country code (e.g. 9198...)"
            inputType = InputType.TYPE_CLASS_PHONE
            singleLine = true
        }
        val addBtn = button("Add client") {
            val n = addName.text.toString().trim()
            val p = cleanPhone(addPhone.text.toString())
            if (n.isBlank() || p.length < 8) {
                toast("Enter a name and a valid phone number")
            } else if (clients.any { it.phone == p }) {
                toast("This number is already saved")
            } else {
                clients.add(Client(n, p)); saveClients(); addName.text.clear(); addPhone.text.clear(); renderClients()
            }
        }
        page.addView(addName); page.addView(addPhone); page.addView(addBtn)

        searchBox = EditText(this).apply {
            hint = "Search by client name or number"
            singleLine = true
        }
        searchBox.addTextChangedListener(SimpleTextWatcher { renderClients() })
        page.addView(searchBox)

        page.addView(TextView(this).apply {
            text = "Only message clients who have agreed to receive updates. WhatsApp opens for your review; this app does not send automatically."
            textSize = 13f
            setTextColor(0xFF7A4A00.toInt())
            setPadding(0, 12, 0, 12)
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(listBox)
    }

    private fun button(label: String, action: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun importContacts() {
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
        )
        var added = 0
        cursor?.use {
            val nameCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val phoneCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val name = it.getString(nameCol)?.trim().orEmpty()
                val phone = cleanPhone(it.getString(phoneCol).orEmpty())
                if (name.isNotBlank() && phone.length >= 8 && clients.none { c -> c.phone == phone }) {
                    clients.add(Client(name, phone)); added++
                }
            }
        }
        saveClients()
        renderClients()
        toast("$added new contacts imported. Review consent before messaging.")
    }

    private fun renderClients() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val q = if (::searchBox.isInitialized) searchBox.text.toString().trim().lowercase(Locale.getDefault()) else ""
        val filtered = clients.filter { it.name.lowercase(Locale.getDefault()).contains(q) || it.phone.contains(q) }
        countText.text = "Saved clients: ${clients.size}  •  Showing: ${filtered.size}"
        if (filtered.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "No clients found."; setPadding(8, 20, 8, 20) })
        }
        filtered.forEach { client ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 12, 16, 12)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            card.addView(TextView(this).apply {
                text = client.name
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF183153.toInt())
            })
            card.addView(TextView(this).apply { text = client.phone; textSize = 14f })
            val consent = CheckBox(this).apply {
                text = "Client has agreed to receive WhatsApp updates"
                isChecked = client.optedIn
                setOnCheckedChangeListener { _, checked ->
                    client.optedIn = checked; saveClients()
                }
            }
            card.addView(consent)
            val note = EditText(this).apply {
                hint = "Notes (area, budget, requirement)"
                setText(client.note)
                textSize = 14f
                setSingleLine(false)
                minLines = 1
                maxLines = 3
            }
            card.addView(note)
            card.addView(button("Save notes") { client.note = note.text.toString(); saveClients(); toast("Saved") })
            card.addView(button("Open WhatsApp Business") {
                if (!client.optedIn) {
                    toast("Please confirm the client has agreed before messaging")
                } else {
                    val message = "Namaste ${client.name}, this is GK Properties. You are receiving this message because you agreed to receive property updates. Reply STOP if you no longer wish to receive them."
                    openWhatsApp(client.phone, message)
                }
            })
            card.addView(button("Delete client") {
                clients.remove(client); saveClients(); renderClients()
            })
            val divider = View(this).apply {
                setBackgroundColor(0xFFDDE3EC.toInt())
                layoutParams = LinearLayout.LayoutParams(-1, 2).apply { topMargin = 16; bottomMargin = 16 }
            }
            listBox.addView(card); listBox.addView(divider)
        }
    }

    private fun openWhatsApp(phone: String, message: String) {
        val uri = Uri.parse("https://wa.me/$phone?text=" + Uri.encode(message))
        val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.whatsapp.w4b") }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                toast("WhatsApp Business not found; opened available WhatsApp/browser")
            } catch (_: Exception) {
                toast("WhatsApp could not be opened")
            }
        }
    }

    private fun cleanPhone(raw: String): String {
        var p = raw.filter { it.isDigit() }
        if (p.length == 10) p = "91$p"
        return p
    }

    private fun saveClients() {
        val arr = JSONArray()
        clients.forEach {
            arr.put(JSONObject().put("name", it.name).put("phone", it.phone)
                .put("optedIn", it.optedIn).put("note", it.note))
        }
        prefs.edit().putString("clients", arr.toString()).apply()
    }

    private fun loadClients() {
        val arr = try { JSONArray(prefs.getString("clients", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val p = cleanPhone(o.optString("phone"))
            if (p.isNotBlank() && clients.none { it.phone == p }) {
                clients.add(Client(o.optString("name"), p, o.optBoolean("optedIn"), o.optString("note")))
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestContacts && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) importContacts()
        else if (requestCode == requestContacts) toast("Contacts permission was not granted")
    }
}

private class SimpleTextWatcher(val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
