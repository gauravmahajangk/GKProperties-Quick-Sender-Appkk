plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "in.gkproperties.clientmanager"
    compileSdk = 35
    defaultConfig {
        applicationId = "in.gkproperties.clientmanager"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
